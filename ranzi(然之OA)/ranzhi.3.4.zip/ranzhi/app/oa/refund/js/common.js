$(document).ready(function()
{    
    $('.side .leftmenu ul').find('a[href*=' + config.currentMethod + ']').parent().addClass('active');
})
