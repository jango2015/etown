$(document).ready(function()
{    
    $('.side .leftmenu ul').find('a[href*=' + config.currentMethod + ']').parent().addClass('active');
    /* expand active tree. */
    $('.tree li.active .hitarea').click();
})
