$(document).ready(function()
{
    $.setAjaxForm('#childForm');
});
