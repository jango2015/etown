<?php
$config->package = new stdclass();
$config->package->apiRoot   = 'http://api.ranzhico.com/extension-';
$config->package->extPathes = array('module', 'bin', 'www', 'library', 'config');
