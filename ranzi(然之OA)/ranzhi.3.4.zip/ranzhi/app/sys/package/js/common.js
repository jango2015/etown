$(document).ready(function()
{
    $.setAjaxLoader('.loadInModal', '#ajaxModal');
})
