$(document).ready(function()
{
    $('.btn-reload').click(function(){ $.reloadAjaxModal();});
});
