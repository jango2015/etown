$(document).ready(function()
{
    if(v.attend)
    {
        $('.sign', parent.document).parent('li').show();
    }
    else
    {
        $('.sign', parent.document).parent('li').hide();
    }
})
