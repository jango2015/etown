<?php
$config->cron = new stdclass();
$config->cron->require = new stdclass();
$config->cron->require->create = 'm,h,dom,mon,dow,command';
$config->cron->require->edit   = 'm,h,dom,mon,dow,command';

$config->cron->maxRunDays = 8;
$config->cron->maxRunTime = 65;

if(!isset($config->global->cron)) $config->global->cron = 1;
