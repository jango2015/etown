$(document).ready(function()
{
    $('#menu li.active').removeClass('active');
    $('#menu a[href*=_' + v.type + ']').parent().addClass('active');
});
